import React, { Component } from 'react';
 import './index.css';
 // Bootstrap components
 import {  Row, Col } from 'reactstrap'
 // Importing GetEmployee file
 import GetEmployees from './components/GetEmployees';
 import Car from './Car';
 import Vehicle from './Vehicle';
 //import EmpComponent from './EmpComponent';
 
 class App extends Component {   //JSX
 render() {
 return (
 <div className="App">
 <div className="docs-example">
 <h1 className="post_heading">Using Redux with React</h1>

 <Row>
 <Col sm="12">
 {/* Includeing re-usable component */}
                                        <GetEmployees />
 </Col>
 </Row>
 <div>
    
 </div>

 <div>
    
 </div>
 </div>
 <div>
 
 </div>s
 </div>
 );
 }
 }
 export default App;
